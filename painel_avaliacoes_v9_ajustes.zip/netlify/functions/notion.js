exports.handler = async function(event) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  const token = process.env.NOTION_TOKEN;
  const databaseId = process.env.NOTION_DATABASE_ID;
  const equipeDatabaseId = process.env.NOTION_EQUIPE_DATABASE_ID;

  if (!token || !databaseId) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Cadastre NOTION_TOKEN e NOTION_DATABASE_ID nas variáveis de ambiente do Netlify."
      })
    };
  }

  const notionHeaders = {
    "Authorization": `Bearer ${token}`,
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json"
  };


  function getTitle(page) {
    const props = page.properties || {};
    const titleProp = props["Nome"] || props["Name"];
    if (!titleProp || !titleProp.title) return "";
    return titleProp.title.map(t => t.plain_text || "").join("");
  }

  async function queryDatabase(id, filter) {
    let results = [];
    let cursor;

    do {
      const body = {
        page_size: 100,
        ...(cursor ? { start_cursor: cursor } : {}),
        ...(filter ? { filter } : {})
      };

      const response = await fetch(`https://api.notion.com/v1/databases/${id}/query`, {
        method: "POST",
        headers: notionHeaders,
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(JSON.stringify(data));
      }

      results = results.concat(data.results || []);
      cursor = data.has_more ? data.next_cursor : undefined;
    } while (cursor);

    return results;
  }

  async function getRelatedTasks(page) {
    const rel = page.properties?.["Tarefas Relacionadas"]?.relation || [];
    const tasks = [];

    for (const item of rel.slice(0, 20)) {
      try {
        const response = await fetch(`https://api.notion.com/v1/pages/${item.id}`, {
          method: "GET",
          headers: notionHeaders
        });
        if (response.ok) tasks.push(await response.json());
      } catch (e) {}
    }

    return tasks;
  }

  try {
    const filter = {
      and: [
        { property: "Arquivar Projeto", checkbox: { equals: false } },
        { property: "Eixo", multi_select: { contains: "Avaliação" } }
      ]
    };

    let results = await queryDatabase(databaseId, filter);
    results = results.filter(page => getTitle(page).trim().startsWith('📝'));

    for (const page of results) {
      page.relatedTasks = await getRelatedTasks(page);
    }

    let equipe = [];
    if (equipeDatabaseId) {
      try {
        equipe = await queryDatabase(equipeDatabaseId, null);
      } catch (e) {
        equipe = [];
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        results,
        equipe,
        lastSync: new Date().toISOString()
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Erro ao consultar o Notion.",
        details: error.message
      })
    };
  }
};
